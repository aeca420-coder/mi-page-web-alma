// Aquí puedes agregar funciones de JavaScript si las necesitas
